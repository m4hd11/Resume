from django import template
from blog.models import Post
from blog.models import Category, Comment
from django.utils import timezone
import math

register = template.Library()

@register.simple_tag(name='totalposts')
def function():
    posts = Post.objects.filter(status=1).count()
    return posts

@register.simple_tag(name='comments_count')
def comments_count(pid):
    return Comment.objects.filter(post=pid, approved=True).count()

@register.simple_tag(name='posts')
def function():
    posts = Post.objects.filter(status=1)
    return posts

@register.filter
def snippet(value,arg=20):
    return value[:arg]

@register.inclusion_tag('blog/blog-latest-posts.html')
def latestposts(arg=3):
    posts = Post.objects.filter(status=1, published_date__lte=timezone.now()).order_by('-published_date')[:arg]
    return {'posts':posts}  

@register.inclusion_tag('blog/blog-post-categories.html')
def postcategories():
    posts = Post.objects.filter(status=1)
    categories = Category.objects.all()
    cat_dict = {}
    for name in categories:
        cat_dict[name] = posts.filter(category=name).count()
    return {'categories': cat_dict}

@register.inclusion_tag('blog/blog-recent-posts.html')
def latestblog(count=3):
    posts = Post.objects.filter(status=1, published_date__lte=timezone.now()).order_by('-published_date')[:count]
    return {'latest_posts': posts}


@register.filter
def slides_count(posts, per_slide=3):
    """Return a range for carousel indicators based on number of posts per slide."""
    try:
        count = posts.count()  # اگر QuerySet باشد
    except:
        count = len(posts)
    num_slides = math.ceil(count / per_slide)
    return range(num_slides)